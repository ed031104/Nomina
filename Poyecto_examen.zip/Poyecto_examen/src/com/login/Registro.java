package com.login;

import com.usuario.ControladorUsuario;
import com.usuario.Usuario;
import java.awt.Color;
import javax.swing.JOptionPane;


public class Registro extends javax.swing.JFrame {
    
   private int xMouse, yMouse; 
   Login ventanaLogin;
   
   //el cosntructor esta recibiendo a la venta Login para no perder la informacion que se ingreso
    public Registro(Login ventanaLogin) {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(this);
        //
        this.ventanaLogin = ventanaLogin;
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background_izquierdo = new javax.swing.JPanel();
        Background_derecho = new javax.swing.JPanel();
        Exit = new javax.swing.JLabel();
        TxtInicio = new javax.swing.JLabel();
        TxtUsuario = new javax.swing.JLabel();
        NombreUsuario = new javax.swing.JTextField();
        TxtContraseña = new javax.swing.JLabel();
        Contraseña = new javax.swing.JPasswordField();
        BtnAtras = new javax.swing.JPanel();
        TxtAtras = new javax.swing.JLabel();
        TxtEmail = new javax.swing.JLabel();
        Email = new javax.swing.JTextField();
        BtnSiguiente = new javax.swing.JPanel();
        TxtSiguiente = new javax.swing.JLabel();
        Separador = new javax.swing.JSeparator();
        separador = new javax.swing.JSeparator();
        separa = new javax.swing.JSeparator();
        Header = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Background_izquierdo.setBackground(new java.awt.Color(255, 153, 153));
        Background_izquierdo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(Background_izquierdo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 170, 400));

        Background_derecho.setBackground(new java.awt.Color(255, 255, 255));
        Background_derecho.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Exit.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        Exit.setForeground(new java.awt.Color(0, 0, 0));
        Exit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Exit.setText("X");
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitMouseExited(evt);
            }
        });
        Background_derecho.add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 0, 30, 30));

        TxtInicio.setBackground(new java.awt.Color(0, 0, 0));
        TxtInicio.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        TxtInicio.setForeground(new java.awt.Color(0, 0, 0));
        TxtInicio.setText("REGISTRATE");
        Background_derecho.add(TxtInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        TxtUsuario.setBackground(new java.awt.Color(0, 0, 0));
        TxtUsuario.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        TxtUsuario.setForeground(new java.awt.Color(0, 0, 0));
        TxtUsuario.setText("USUARIO");
        Background_derecho.add(TxtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, -1));

        NombreUsuario.setBackground(new java.awt.Color(255, 255, 255));
        NombreUsuario.setForeground(new java.awt.Color(0, 0, 0));
        NombreUsuario.setBorder(null);
        NombreUsuario.setCaretColor(new java.awt.Color(255, 255, 255));
        NombreUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Background_derecho.add(NombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 190, 30));

        TxtContraseña.setBackground(new java.awt.Color(0, 0, 0));
        TxtContraseña.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        TxtContraseña.setForeground(new java.awt.Color(0, 0, 0));
        TxtContraseña.setText("CONTRASEÑA");
        Background_derecho.add(TxtContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, -1, -1));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setForeground(new java.awt.Color(0, 0, 0));
        Contraseña.setBorder(null);
        Background_derecho.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, 210, 30));

        BtnAtras.setBackground(new java.awt.Color(255, 153, 153));
        BtnAtras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        TxtAtras.setBackground(new java.awt.Color(255, 255, 255));
        TxtAtras.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        TxtAtras.setForeground(new java.awt.Color(255, 255, 255));
        TxtAtras.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TxtAtras.setText("ATRAS");
        TxtAtras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TxtAtrasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TxtAtrasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TxtAtrasMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BtnAtrasLayout = new javax.swing.GroupLayout(BtnAtras);
        BtnAtras.setLayout(BtnAtrasLayout);
        BtnAtrasLayout.setHorizontalGroup(
            BtnAtrasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 170, Short.MAX_VALUE)
            .addGroup(BtnAtrasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(BtnAtrasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(TxtAtras, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        BtnAtrasLayout.setVerticalGroup(
            BtnAtrasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
            .addGroup(BtnAtrasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(BtnAtrasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(TxtAtras, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Background_derecho.add(BtnAtras, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 170, 30));

        TxtEmail.setBackground(new java.awt.Color(0, 0, 0));
        TxtEmail.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        TxtEmail.setForeground(new java.awt.Color(0, 0, 0));
        TxtEmail.setText("EMAIL");
        Background_derecho.add(TxtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        Email.setBackground(new java.awt.Color(255, 255, 255));
        Email.setForeground(new java.awt.Color(0, 0, 0));
        Email.setBorder(null);
        Email.setCaretColor(new java.awt.Color(255, 255, 255));
        Email.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Background_derecho.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 440, 30));

        BtnSiguiente.setBackground(new java.awt.Color(255, 153, 153));
        BtnSiguiente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        TxtSiguiente.setBackground(new java.awt.Color(255, 255, 255));
        TxtSiguiente.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        TxtSiguiente.setForeground(new java.awt.Color(255, 255, 255));
        TxtSiguiente.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TxtSiguiente.setText("REGISTRAR");
        TxtSiguiente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TxtSiguienteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TxtSiguienteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TxtSiguienteMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BtnSiguienteLayout = new javax.swing.GroupLayout(BtnSiguiente);
        BtnSiguiente.setLayout(BtnSiguienteLayout);
        BtnSiguienteLayout.setHorizontalGroup(
            BtnSiguienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 170, Short.MAX_VALUE)
            .addGroup(BtnSiguienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(BtnSiguienteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(TxtSiguiente, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        BtnSiguienteLayout.setVerticalGroup(
            BtnSiguienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
            .addGroup(BtnSiguienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(BtnSiguienteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(TxtSiguiente, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        Background_derecho.add(BtnSiguiente, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 340, 170, 30));

        Separador.setForeground(new java.awt.Color(0, 0, 0));
        Background_derecho.add(Separador, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 440, 20));

        separador.setForeground(new java.awt.Color(0, 0, 0));
        Background_derecho.add(separador, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 190, 20));

        separa.setForeground(new java.awt.Color(0, 0, 0));
        Background_derecho.add(separa, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 180, 210, 20));

        getContentPane().add(Background_derecho, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 0, 610, 399));

        Header.setBackground(new java.awt.Color(0, 0, 0));
        Header.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                HeaderMouseDragged(evt);
            }
        });
        Header.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                HeaderMousePressed(evt);
            }
        });
        Header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(Header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
                                                                            //son los colores de las entradas y salidas de los botones
    private void TxtAtrasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtAtrasMouseEntered
        TxtAtras.setForeground(new Color(255,255,255));
       BtnAtras.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_TxtAtrasMouseEntered

    private void TxtAtrasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtAtrasMouseExited
        BtnAtras.setBackground(new Color(255,153,153));
        TxtAtras.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_TxtAtrasMouseExited

    private void HeaderMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HeaderMouseDragged
         int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);  //hace que centre la pestaña y no tenga problemas a la hora de moverse
    }//GEN-LAST:event_HeaderMouseDragged

    private void HeaderMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HeaderMousePressed
             xMouse = evt.getX();  //hace que se pueda mover la pestaña a cualquier lado
             yMouse = evt.getY();
    }//GEN-LAST:event_HeaderMousePressed

    private void ExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseEntered
        Exit.setForeground(Color.red);
    }//GEN-LAST:event_ExitMouseEntered

    private void ExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseExited
        Exit.setForeground(Color.BLACK);
    }//GEN-LAST:event_ExitMouseExited

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
       System.exit(0);
    }//GEN-LAST:event_ExitMouseClicked

    private void TxtSiguienteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtSiguienteMouseEntered
       TxtSiguiente.setForeground(new Color(255,255,255));
       BtnSiguiente.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_TxtSiguienteMouseEntered

    private void TxtSiguienteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtSiguienteMouseExited
        BtnSiguiente.setBackground(new Color(255,153,153));
        TxtSiguiente.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_TxtSiguienteMouseExited

    private void TxtAtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtAtrasMouseClicked
        ventanaLogin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_TxtAtrasMouseClicked

    private void TxtSiguienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtSiguienteMouseClicked
        //sin no hay nada en los Jtexfields te devuelve un mensaje
        if(NombreUsuario.getText().isEmpty() || Contraseña.getText().isEmpty() || Email.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Llena todas las casillas.");
        }
        else{
            //guarda los datos ngresados en variables
        String usuario = NombreUsuario.getText();
        String contraseña = Contraseña.getText();
        String email = Email.getText();
        //se inicializa un usuario y se agregan los datos que se ingresaron 
        Usuario user = new Usuario(contraseña, usuario, email);
        
        //se crea una variable de tipo bolean  y guarda el metodo agregar usuario
        boolean respuesta = ventanaLogin.getControladoruser().AgregarUsuario(user);
        //sino encuentra al usuario ingresado lo guardará
        if (respuesta){
            JOptionPane.showMessageDialog(null, "El usuario se ha agregado");
            //si lo encuentra en el fichero, retornara que ya está ingresado
        }else{
            JOptionPane.showMessageDialog(null, "El usuario ya está registrada");
        }
        
        ventanaLogin.setVisible(true);
        this.dispose();
        }
    }//GEN-LAST:event_TxtSiguienteMouseClicked
    
    
    
    
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background_derecho;
    private javax.swing.JPanel Background_izquierdo;
    private javax.swing.JPanel BtnAtras;
    private javax.swing.JPanel BtnSiguiente;
    private javax.swing.JPasswordField Contraseña;
    private javax.swing.JTextField Email;
    private javax.swing.JLabel Exit;
    private javax.swing.JPanel Header;
    private javax.swing.JTextField NombreUsuario;
    private javax.swing.JSeparator Separador;
    private javax.swing.JLabel TxtAtras;
    private javax.swing.JLabel TxtContraseña;
    private javax.swing.JLabel TxtEmail;
    private javax.swing.JLabel TxtInicio;
    private javax.swing.JLabel TxtSiguiente;
    private javax.swing.JLabel TxtUsuario;
    private javax.swing.JSeparator separa;
    private javax.swing.JSeparator separador;
    // End of variables declaration//GEN-END:variables


}



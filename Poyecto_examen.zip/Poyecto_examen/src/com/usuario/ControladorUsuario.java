package com.usuario;

import com.controlador.fichero.controladorFicheroUsuario;

public class ControladorUsuario {
controladorFicheroUsuario fichero= new controladorFicheroUsuario();

public ControladorUsuario(){
    
}

public boolean AgregarUsuario(Usuario usuario){
    //se crea un Usuario con el nombre aux y este va a contener el metodo leer fichero, que busca un empleado por su nombre
    Usuario aux = fichero.leerFicheroUsuario(usuario.getNombre_usuario());
    //si el usuario no está, lo registra al fichero y nos retorna el verdadero
    if(aux == null){
        fichero.ingresarficherousuario(usuario);
        return true;
    }
    //si no se cumple retorna falso a la condición
    return false;
    }
}





package com.usuario;
import java.util.ArrayList;

public class ControladorUsuario {

private ArrayList<Usuario> ListaUsuario;


public ControladorUsuario(){
    ListaUsuario = new ArrayList<>();
}


public Usuario BuscarUsuario(String Nombre_usuario){
    
    for (int i = 0; i < ListaUsuario.size(); i++) {
        Usuario usuario = ListaUsuario.get(i);
        if(usuario != null){
            if(usuario.getNombre_usuario().equals(Nombre_usuario) ){
                return usuario;
            }
        }
    }
    return null;
}

public boolean AgregarUsuario(Usuario usuario){

    Usuario aux = BuscarUsuario(usuario.getNombre_usuario());
    if(aux == null){
        
        ListaUsuario.add(usuario);
        
        return true;
    }
    return false;
}

}

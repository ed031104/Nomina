package com.usuario;

import com.controlador.fichero.controladorFicheroUsuario;

public class ControladorUsuario {
controladorFicheroUsuario fichero= new controladorFicheroUsuario();

public ControladorUsuario(){
    
}

public boolean AgregarUsuario(Usuario usuario){
    
    Usuario aux = fichero.leerFicheroUsuario(usuario.getNombre_usuario());
    if(aux == null){
        fichero.ingresarficherousuario(usuario);
        return true;
    }
    return false;
    }
}





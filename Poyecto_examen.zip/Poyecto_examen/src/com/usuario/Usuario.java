package com.usuario;
import java.util.ArrayList;

public class Usuario {
   
    private String contraseña;
    private String Nombre_usuario;
    private String email;
   

    public Usuario(){
    }
    public Usuario(String contraseña, String Nombre_usuario, String email) {
        this.contraseña = contraseña;
        this.Nombre_usuario = Nombre_usuario;
        this.email = email;
    }
    

    

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre_usuario() {
        return Nombre_usuario;
    }

    public void setNombre_usuario(String Nombre_usuario) {
        this.Nombre_usuario = Nombre_usuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    

  
   

}

package com.nomina.empleado;

public class Empleado {
    
//atributos
    private double sueldoMesual,noInss,sueldoAnual,bono,prestamos,horasExtras,ingresosHorasExtras
    ,salarioBruto,inssLaboral,ir,totalDeducciones,netoRecibir,inssPatronal,inatec,vacaciones,treceavoMes;
    private String nombre,cargo;
    private int añosAntiguedad;
    private double pagoAntiguedad;
    
    //metodo constructor
    public Empleado(double noInss, String nombre, String cargo,
    double sueldoMensual, double horasExtras, double ingresosHorasExtras, int añosAntiguedad,double pagoAntiguedad,
    double bono, double salarioBruto, double inssLaboral,double ir ,double prestamos, double totalDeducciones, double netorecibir,
    double inssPatronal,double inatec,double vacaciones,double treceavoMes,double sueldoAnual) {
        
        this.sueldoMesual = sueldoMensual;
        this.sueldoAnual = sueldoAnual;
        this.bono = bono;
        this.prestamos = prestamos;
        this.noInss = noInss;
        this.nombre = nombre;
        this.cargo = cargo;
        this.horasExtras = horasExtras;
        this.ingresosHorasExtras = ingresosHorasExtras;
        this.añosAntiguedad = añosAntiguedad;
        this.pagoAntiguedad = pagoAntiguedad;
        this.salarioBruto = salarioBruto;
        this.inssLaboral = inssLaboral;
        this.ir = ir;
        this.totalDeducciones = totalDeducciones;
        this.netoRecibir = netorecibir;
        this.inssPatronal = inssPatronal;
        this.inatec = inatec;
        this.vacaciones = vacaciones;
        this.treceavoMes = treceavoMes;
    }
    
    
    //metodo set y get
    public double getPagoAntiguedad() {
        return pagoAntiguedad;
    }

    //metodos get y set
    public void setPagoAntiguedad(double pagoAntiguedad) {    
        this.pagoAntiguedad = pagoAntiguedad;
    }

    public Empleado() {
    }

    public double getSueldoMesual() {
        return sueldoMesual;
    }

    public void setSueldoMesual(double sueldoMesual) {
        this.sueldoMesual = sueldoMesual;
    }

    public double getSueldoAnual() {
        return sueldoAnual;
    }

    public void setSueldoAnual(double sueldoAnual) {
        this.sueldoAnual = sueldoAnual;
    }

    public double getBono() {
        return bono;
    }

    public void setBono(double bono) {
        this.bono = bono;
    }

    public double getPrestamos() {
        return prestamos;
    }

    public void setPrestamos(double prestamos) {
        this.prestamos = prestamos;
    }

    public double getNoInss() {
        return noInss;
    }

    public void setNoInss(double noInss) {
        this.noInss = noInss;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getHorasExtras() {
        return horasExtras;
    }

    public void setHorasExtras(double horasExtras) {
        this.horasExtras = horasExtras;
    }

    public double getIngresosHorasExtras() {
        return ingresosHorasExtras;
    }

    public void setIngresosHorasExtras(double ingresosHorasExtras) {
        this.ingresosHorasExtras = ingresosHorasExtras;
    }

    public int getañosAntiguedad() {
        return añosAntiguedad;
    }

    public void setañosAntiguedad(int Antiguedad) {
        this.añosAntiguedad = Antiguedad;
    }

    public double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public double getInssLaboral() {
        return inssLaboral;
    }

    public void setInssLaboral(double inssLaboral) {
        this.inssLaboral = inssLaboral;
    }

    public double getIr() {
        return ir;
    }

    public void setIr(double ir) {
        this.ir = ir;
    }

    public double getTotalDeducciones() {
        return totalDeducciones;
    }

    public void setTotalDeducciones(double totalDeducciones) {
        this.totalDeducciones = totalDeducciones;
    }

    public double getNetoRecibir() {
        return netoRecibir;
    }

    public void setNetoRecibir(double netoRecibir) {
        this.netoRecibir = netoRecibir;
    }

    public double getInssPatronal() {
        return inssPatronal;
    }

    public void setInssPatronal(double inssPatronal) {
        this.inssPatronal = inssPatronal;
    }

    public double getInatec() {
        return inatec;
    }

    public void setInatec(double inatec) {
        this.inatec = inatec;
    }

    public double getVacaciones() {
        return vacaciones;
    }

    public void setVacaciones(double vacaciones) {
        this.vacaciones = vacaciones;
    }

    public double getTreceavoMes() {
        return treceavoMes;
    }

    public void setTreceavoMes(double treceavoMes) {
        this.treceavoMes = treceavoMes;
    }

    public int getAñosAntiguedad() {
        return añosAntiguedad;
    }

    public void setAñosAntiguedad(int añosAntiguedad) {
        this.añosAntiguedad = añosAntiguedad;
    }
    
    
}

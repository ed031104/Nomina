package com.nomina.empleado;
import javax.swing.JOptionPane;
import com.controlador.fichero.controladorFicheroEmpleado;


public class ControladorEmpleado {
    


public ControladorEmpleado(){

}


//metodos
public void AgregarEmpleado(Empleado empleado){
 controladorFicheroEmpleado empleados = new controladorFicheroEmpleado();
        empleados.crearficheroempleado(empleado);
}

public void ingresarDatos(){
    double noInss= Double.parseDouble(JOptionPane.showInputDialog(null, "ingresar numero inss")); 
    String nombre = JOptionPane.showInputDialog(null, "ingresar nombre");
    String cargo = JOptionPane.showInputDialog(null, "ingrsar cargo");
    double sueldoMensual= Double.parseDouble(JOptionPane.showInputDialog(null, "ingresar sueldo mensual")); 
    double horasExtras= Double.parseDouble(JOptionPane.showInputDialog(null, "ingresar el numero de horas extras"));
    int añosAntiguedad = Integer.parseInt(JOptionPane.showInputDialog(null, "ingresar el numero de años de antiguedad"));
    double bono= Double.parseDouble(JOptionPane.showInputDialog(null, "ingresar bono"));
    double prestamos= Double.parseDouble(JOptionPane.showInputDialog(null, "ingresar prestamo"));
    
    //se guardan los datos obtenidos de los showInputDialog y se agregan a la clase nueva de empleado 
    Empleado empleados = new Empleado(noInss, nombre, cargo, sueldoMensual, horasExtras,0,añosAntiguedad
    , 0,bono, 0, 0
    , 0, prestamos, 0, 0, 0);
    //se agrega el nuevo empleado en el metodo agregarEmpleado
    AgregarEmpleado(empleados);
}


}





    


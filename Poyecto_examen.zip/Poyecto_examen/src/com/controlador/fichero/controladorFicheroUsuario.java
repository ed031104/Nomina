
package com.controlador.fichero;

import com.usuario.Usuario;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class controladorFicheroUsuario {
    ArrayList<Usuario>usuario = new ArrayList<>();
    
    //metodo constructor
    public controladorFicheroUsuario(){
    }
    
    //metodos
     public void ingresarficherousuario(Usuario usuario){
    
        FileWriter fw = null;
        try {
            //crea fichero
            fw = new FileWriter("usuario.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            //imprime los datos del usuario en el fichero
            pw.print(usuario.getContraseña()+",");
            pw.print(usuario.getNombre_usuario()+",");
            pw.print(usuario.getEmail()+"\n");
            pw.close(); 
        }catch(Exception e){
        }
    }  

 public Usuario leerFicheroUsuario(String Nombre_usuario){
     try {
         //lee la ruta del fichero
        FileReader fr = new FileReader("usuario.txt");
        BufferedReader bf = new BufferedReader(fr);
        
        String cadena;
        //la variable recorre todo el fichero cuando haya datos
        while ((cadena = bf.readLine()) != null) {
            //analiza cada atributo, si esta en separado por una ,
            String[] partes = cadena.split(",");
                //se cumple mientras parte se encuentre divido en 3 atributos
            if (partes.length == 3) {
                    String contraseña = partes[0].trim();
                    String nombre = partes[1].trim();
                    String email = partes[2].trim();
                    //agrega al nuevo usuario aal arraylist
                    usuario.add(new Usuario(contraseña, nombre, email));
                }
        }
        //recorre la lista usuario 
        for (int i = 0; i < usuario.size(); i++) {
            
       //se obtiene un elemento de la lista usuario en la posición i y se almacena en la variable Buscadorusuario
        Usuario Buscadorusuario = usuario.get(i);
        //condiciona si el usuario esta en el fichero y si el usuario es igual al nombre que se ingrese te retorna el 
        //usuario
        if(Buscadorusuario != null){
            if(Buscadorusuario.getNombre_usuario().equals(Nombre_usuario) ){
                return Buscadorusuario;
                    }
                }
            }
            return null; 
     }catch(IOException e){
      e.printStackTrace();   
     }
        return null;       
    }
 
   
 
}

 
package com.controlador.fichero;

import com.nomina.empleado.Empleado;
import com.controlador.nomina.CalculosNomina;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;



public class controladorFicheroEmpleado {
    
    
    //metodo constructor
    public controladorFicheroEmpleado(){
        
    }
    
    // metodos
public void crearficheroempleado(Empleado empleado){
    
    CalculosNomina controladornomina = new CalculosNomina();
    //calculos antes de regitrar en el fichero 
    controladornomina.pagoHorasExtras(empleado);
    controladornomina.pagoantiguedad(empleado);
    controladornomina.calculoSalarioBruto(empleado);
    controladornomina.calculoinss(empleado);
    controladornomina.calculoir(empleado);
    controladornomina.calculoTotalDeducciones(empleado);
    controladornomina.calculoNetoRecibir(empleado);
    controladornomina.calculoInssPatronal(empleado);
    controladornomina.calculoInatec(empleado);
    controladornomina.calculoVacaciones(empleado);
    controladornomina.calculoTreceavoMes(empleado);
    
    FileWriter fw = null;
    try {
        //se crea un nuevo fichero con el nombre empleado.txt
        fw = new FileWriter("empleado.txt",true);
        BufferedWriter bw = new BufferedWriter(fw);
        //se escribe en la la ruta del txt
        PrintWriter pw = new PrintWriter(bw);
        //se agregan los atributos de la clase enmpleado en el fichero
        pw.print(empleado.getNoInss()+",");
        pw.print(empleado.getNombre()+",");
        pw.print(empleado.getCargo()+",");
        pw.print(empleado.getSueldoMesual()+",");
        pw.print(empleado.getHorasExtras()+",");
        pw.print(empleado.getIngresosHorasExtras()+",");
        pw.print(empleado.getañosAntiguedad()+",");
        pw.print(empleado.getPagoAntiguedad()+",");
        pw.print(empleado.getBono()+",");
        pw.print(empleado.getSalarioBruto()+",");
        pw.print(empleado.getInssLaboral()+",");
        pw.print(empleado.getIr()+",");
        pw.print(empleado.getPrestamos()+",");
        pw.print(empleado.getTotalDeducciones()+",");
        pw.print(empleado.getNetoRecibir()+",");
        pw.print(empleado.getInssPatronal()+",");
        pw.print(empleado.getInatec()+",");
        pw.print(empleado.getVacaciones()+",");
        pw.print(empleado.getTreceavoMes()+",");
        pw.print(empleado.getSueldoAnual()+"\n");
        //se cierra el proceso
        pw.close();
             } catch (Exception e) {
         }
    }


}


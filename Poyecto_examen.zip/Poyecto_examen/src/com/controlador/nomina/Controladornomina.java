
package com.controlador.nomina;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Controladornomina {
    
    public Controladornomina() {
    }

    public DefaultTableModel MostrarEmpleados(){
        //se crea un vector y se le agregan los nombre de las celdas superiores
        Vector vx = new Vector();
        vx.addElement("No inss");
        vx.addElement("Nombre");
        vx.addElement("Cargo");
        vx.addElement("Sueldo mensual");
        vx.addElement("Horas extras");
        vx.addElement("Pago de horas extras");
        vx.addElement("Años de antiguedad");
        vx.addElement("Pago por años de antiguedad");
        vx.addElement("Bono");
        vx.addElement("Salario bruto");
        vx.addElement("Inss laboral");
        vx.addElement("Ir");
        vx.addElement("Prestamos");
        vx.addElement("Total de deducciones");
        vx.addElement("neto a recibir");
        //se llama la libreria defaulttable y se ingresa el vector en la linea 0
        DefaultTableModel dtm = new DefaultTableModel(vx,0);
        
        try{
            //lee la ruta de fichero
            FileReader fr = new FileReader("empleado.txt");
            BufferedReader bf = new BufferedReader(fr);
            //la variable recorre todo el fichero cuando haya datos
            String cadena;
            //cadena es igual al lectura del fichero y si no hay nada no se cumple
            while ((cadena = bf.readLine()) != null) {
                //se inicializa la libreria stringtokennizer para dividir los datos del fichero con comas 
                StringTokenizer dato = new StringTokenizer(cadena,",");
                //se crea un nuevo vector
                Vector datosempleados = new Vector();
                    //verifica si en el stringtokennizer dato enncuentra mas tokens disponibles en la cadena
                while(dato.hasMoreTokens()){
                    //se llama al vector datosempleados y guarda la cadena que separo dato
                    datosempleados.addElement(dato.nextToken());
                }
                //se agrega a la tabla el vector de datosempleados.    
                dtm.addRow(datosempleados);
            }
        
        }catch(Exception e){
            JOptionPane.showInternalMessageDialog(null, e);
        }
        return dtm;
    }

    
}

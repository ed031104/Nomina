
package com.controlador.nomina;

import com.controlador.fichero.controladorFicheroEmpleado;
import com.nomina.empleado.Empleado;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Controladornomina {
        ArrayList<Empleado> datosempleados = new ArrayList<>();
        controladorFicheroEmpleado controladorfichero = new controladorFicheroEmpleado();
        //metodo constructor
    public Controladornomina(){
    }
    
    
    //métodos
    public DefaultTableModel MostrarEmpleadosJtable(){
        //se crea un vector y se le agregan los nombre de las celdas superiores
        Vector vx = new Vector();
        vx.addElement("No inss");
        vx.addElement("Nombre");
        vx.addElement("Cargo");
        vx.addElement("Sueldo mensual");
        vx.addElement("Horas extras");
        vx.addElement("Pago de horas extras");
        vx.addElement("Años de antiguedad");
        vx.addElement("Pago por años de antiguedad");
        vx.addElement("Bono");
        vx.addElement("Salario bruto");
        vx.addElement("Inss laboral");
        vx.addElement("Ir");
        vx.addElement("Prestamos");
        vx.addElement("Total de deducciones");
        vx.addElement("neto a recibir");
        vx.addElement("Inss patronal");
        vx.addElement("INATEC");
        vx.addElement("Vacaciones");
        vx.addElement("Treceavo mes");
        
        
        //se llama la libreria defaulttable y se ingresa el vector en la linea 0
        DefaultTableModel dtm = new DefaultTableModel(vx,0);
        try{
            FileReader fr = new FileReader("empleado.txt");
            BufferedReader bf = new BufferedReader(fr);
            String cadena;
            //la variable recorre todo el fichero cuando haya datos
            while ((cadena = bf.readLine()) != null) {
            //separa todo por tokens, cuado lea una coma
                StringTokenizer dato = new StringTokenizer(cadena,",");
                //se crea un vector
                Vector x = new Vector();
                //mira si hay mas tokens, y si los hay los añade
                while(dato.hasMoreTokens()){
                    x.addElement(dato.nextToken());
                }
                //se agrega al modelo de la tabla el vector
                dtm.addRow(x);
            }
        }catch(Exception e){
            JOptionPane.showInternalMessageDialog(null, e);
        }
        return dtm;
        
    }
    public Empleado buscarEmpleado(String nombreempleado){ 
    try {
         //lee la ruta del fichero
        FileReader fr = new FileReader("empleado.txt");
        BufferedReader bf = new BufferedReader(fr);
        
        String cadena;
        //la variable recorre todo el fichero cuando haya datos
        while ((cadena = bf.readLine()) != null) {
            String[] partes = cadena.split(",");
            if(partes.length == 20){
                //guarda en variables, los datos del fichero
                double Noinss = Double.parseDouble(partes[0].trim());
                String nombre = partes[1].trim();
                String cargo = partes[2].trim();
                double sueldomensual = Double.parseDouble(partes[3]);
                double horasextras = Double.parseDouble(partes[4].trim());
                double pagoHorasExtras = Double.parseDouble(partes[5]);
                int añosAntiguedad = Integer.parseInt(partes[6].trim());
                double pagoAntiguedad = Double.parseDouble(partes[7]);
                double bono = Double.parseDouble(partes[8]);
                double salarioBruto = Double.parseDouble(partes[9]);
                double inssLaboral = Double.parseDouble(partes[10]);
                double ir = Double.parseDouble(partes[11]);
                double prestamos = Double.parseDouble(partes[12]);
                double totalDeducciones = Double.parseDouble(partes[13]);
                double netoRecibir = Double.parseDouble(partes[14]);
                double inssPatronal = Double.parseDouble(partes[15]);
                double inatec = Double.parseDouble(partes[16]);
                double vacaciones = Double.parseDouble(partes[17]);
                double treceavomes = Double.parseDouble(partes[18]);
                double saldoAnual = Double.parseDouble(partes[19]);
                //se agrega en nuevo empleado los datos extraidos
                datosempleados.add(new Empleado(Noinss, nombre, cargo, sueldomensual,
                        horasextras, pagoHorasExtras, añosAntiguedad,
                        pagoAntiguedad, bono, salarioBruto, inssLaboral, ir, prestamos, totalDeducciones,
                        netoRecibir, inssPatronal, inatec, vacaciones, treceavomes, saldoAnual));
            }
        }
        //recorre el array empleados, y compara si el nombre es igual a lo que se ingrese
        for(Empleado empleado : datosempleados){
                  if (empleado.getNombre().equals(nombreempleado)) {
                 return empleado;
                 }
                }
      }catch(IOException e){
      e.printStackTrace();   
     }  
        return null;
}
    public void imprimirBusquedaEmpleado(JTable jTable, JTextField nombre){
  
    
        String nombreBuscado = nombre.getText(); // Suponiendo que el nombre se obtiene de un JTextField.
    Empleado empleadoEncontrado = buscarEmpleado(nombreBuscado);

if (empleadoEncontrado != null) {
    // Llenar la JTable con el empleado encontrado
    DefaultTableModel model = (DefaultTableModel) jTable.getModel();
    model.setRowCount(0); // Limpiar la tabla
    //se agrega al modelo los empleados
    model.addRow(new Object[]{empleadoEncontrado.getNoInss(), empleadoEncontrado.getNombre(), empleadoEncontrado.getCargo(),
        empleadoEncontrado.getSueldoMesual(),empleadoEncontrado.getHorasExtras(), empleadoEncontrado.getIngresosHorasExtras(), 
        empleadoEncontrado.getañosAntiguedad(),empleadoEncontrado.getPagoAntiguedad(), empleadoEncontrado.getBono(),
        empleadoEncontrado.getSalarioBruto(), empleadoEncontrado.getInssLaboral(), empleadoEncontrado.getIr(), 
        empleadoEncontrado.getPrestamos(), empleadoEncontrado.getTotalDeducciones(),empleadoEncontrado.getNetoRecibir(), 
        empleadoEncontrado.getInssPatronal(), empleadoEncontrado.getInatec(), empleadoEncontrado.getVacaciones(), 
        empleadoEncontrado.getTreceavoMes(), empleadoEncontrado.getSueldoAnual()});
        } else {
            JOptionPane.showMessageDialog(null, "Empleado no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public void borrarTodosEmpleados(){
    String nombreArchivo = "empleado.txt";

        try {
            // Crear un FileWriter en modo de escritura (sobrescribir)
            FileWriter fileWriter = new FileWriter(nombreArchivo, false);

            // No escribir ningún dato en el archivo

            // Cerrar el FileWriter
            fileWriter.close();

        } catch (IOException e) {
            
        }
    }
    
}
     





package com.controlador.nomina;

import com.nomina.empleado.Empleado;

public class CalculosNomina {
    //metodo constructor
    public CalculosNomina(){
    }
    
    //metodos 
public void pagoHorasExtras(Empleado empleado){
    double factor= 240;
    empleado.setIngresosHorasExtras((empleado.getSueldoMesual()/factor) *2*empleado.getHorasExtras());
    
}
public void pagoantiguedad(Empleado empleado){
    //se crean las variables locales
    double pagoantiguedad= 0;
    int añosantiguedad=empleado.getañosAntiguedad();
    double sueldo = empleado.getSueldoMesual(); 
            
    //va condicionando si el año de antigueda es igual a "n" año de antiguedad, te calcula el pago de antiguedad
    if(añosantiguedad == 1){
            pagoantiguedad = sueldo * 0.03;
        }
            if (añosantiguedad == 2) {
                pagoantiguedad = sueldo * 0.05;
            }   
                if (añosantiguedad == 3) {
                pagoantiguedad = sueldo * 0.07;
                }   
                    if (añosantiguedad == 4) {
                    pagoantiguedad = sueldo * 0.09;
                    }       
                        if(añosantiguedad == 5){
                        pagoantiguedad = sueldo * 0.1;
                        }
                        if (añosantiguedad == 6){
                            pagoantiguedad = sueldo * 0.11;
                        }
                         if(añosantiguedad == 7){
                            pagoantiguedad = sueldo * 0.12;
                         }    
                            if(añosantiguedad == 8){
                            pagoantiguedad = sueldo * 0.13;
                            }      
                                if (añosantiguedad == 9) {
                                    pagoantiguedad = sueldo * 0.14;
                                }       
                                    if(añosantiguedad == 10){
                                        pagoantiguedad = sueldo * 0.15;
                                    }       
                                        if(añosantiguedad == 11){
                                            pagoantiguedad = sueldo * 0.155;
                                        }
                                        
                                        if(añosantiguedad==12){
                                            pagoantiguedad = sueldo * 0.16;
                                            }   
                                                if( añosantiguedad ==13){
                                                pagoantiguedad = sueldo * 0.165;
                                                }   
                                                    if(añosantiguedad == 14){
                                                        pagoantiguedad = sueldo * 0.17;
                                                    }       
                                                        if (añosantiguedad == 15){
                                                            pagoantiguedad = sueldo * 0.175;
                                                        }       
                                                            if(añosantiguedad ==16){
                                                                pagoantiguedad = sueldo * 0.18;
                                                            }       
                                                                if(añosantiguedad==17){
                                                                pagoantiguedad = sueldo * 0.185;
                                                                }   
                                                                    if(añosantiguedad == 18){
                                                                        pagoantiguedad = sueldo * 0.19;
                                                                    }       
                                                                        if(añosantiguedad == 19){
                                                                        pagoantiguedad = sueldo * 0.195;
                                                                        }   
                                                                            if(añosantiguedad >=20){
                                                                                pagoantiguedad = sueldo * 0.20;
     }
      //añade de la clase empleado su pago antiguedad va a ser igual al calculo condicional que se realizó                                                                      
       empleado.setPagoAntiguedad(pagoantiguedad);
}
public void calculoSalarioBruto(Empleado empleado){
 // se crea la variable y suma todos ingresos del empleado   
double salarioBruto= empleado.getSueldoMesual() + empleado.getHorasExtras() + empleado.getBono() + empleado.getPagoAntiguedad() ;
//lo registra en la clase empleado del atributo salario bruto
empleado.setSalarioBruto(salarioBruto);
}
public void calculoinss(Empleado empleado){
    // se crea una variable local llamada calculo inss, y multiplica el atributo del empleado salario bruto por el 7%
    double calculoinss = empleado.getSalarioBruto() *0.07;
    //registra el calculo que se hizo en la clase empleado del atributo inss laboral
    empleado.setInssLaboral(calculoinss);

}
public void calculoir(Empleado empleado){
    //se crean las variables locales
   double baseImponible = empleado.getSalarioBruto()- empleado.getInssLaboral();
   double sueldoAnual = baseImponible*12;
   //se registra el sueldo anual del empleado en el atributo sueldo anual de la clase empleado
   empleado.setSueldoAnual(sueldoAnual);
   
    tarifaProgresivaIr(empleado);
}
public void tarifaProgresivaIr(Empleado empleado){
    //se crean las variables locales
    double sueldoAnual = empleado.getSueldoAnual();
    double deducible = 0;
    double porcentaje = 0;
    double impuestoBase=0;
    double salarioMenosDeducible=0;
    double IrAnual= 0;
    double IrMensual= 0;
    //se hacen calculos condiconales en el cual se conduciona que si el sueldo anual es "n" ingresos hasta "n" ingrsos
    // y dependiendo el salario se le va registrare cual es su deducible, porcentaje, impuesto base.
    if(sueldoAnual >= 1 && sueldoAnual <=100000){
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual = (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >= 100001 && sueldoAnual <=200000){
        deducible = 100000;
        porcentaje= 0.15;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >= 200001 && sueldoAnual <=350000){
        deducible = 200000;
        porcentaje= 0.2;
        impuestoBase = 15000;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >= 350001 && sueldoAnual <=500000){
        deducible = 350000;
        porcentaje= 0.25;
        impuestoBase = 45000;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >=500001){
        deducible = 500000;
        porcentaje= 0.3;
        impuestoBase = 82500;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    //se registra en el atributo ir de la clase empleado el calculocondicional de la tarifa del ir
    empleado.setIr(IrMensual);
}
public void calculoTotalDeducciones(Empleado empleado){
//se crea una variable local llamda totaldeducciones, en ella se registra la suma de todas las deducciones del empleado
double totaldeducciones= empleado.getInssLaboral()+ empleado.getIr()+ empleado.getPrestamos();
//se registra el calculo que se hizo en el atributo totalDeducciones de la clase empelado
empleado.setTotalDeducciones(totaldeducciones);
}
public void calculoNetoRecibir(Empleado empleado){
//se hace una variable local la cual calcula el salrio neto, resta el salario bruto con total de dedducciones     
double salarioNeto= empleado.getSalarioBruto()-empleado.getTotalDeducciones();
//registra en el atributo neto a recibir de la clase empleado el calculo del salario bruto
empleado.setNetoRecibir(salarioNeto);
}
public void calculoInssPatronal(Empleado empleado){
//se hace una variable inss patronal que multiplica el salario bruto por el 23%
double inssPatronal = empleado.getSalarioBruto() * 0.23;
//se registra el calculo en el atributo de InssPatronal de la clase empleado
empleado.setInssPatronal(inssPatronal);
}
public void calculoInatec(Empleado empleado){
// se hace una variable local llamada inatec que multiplica ek salario bruto por el 2%
double inatec = empleado.getSalarioBruto() * 0.02;
//registra el calculo en el atributo de Inatec de la clase empleado
empleado.setInatec(inatec);
}
public void calculoVacaciones(Empleado empleado){
   //se crea la constante factor
   double factor= 0.083333;
   //se crea la varible local vacaciones multiplica el salario mensual por el factor
   double vacaciones = empleado.getSueldoMesual() * factor;
   //se registra el calculo en el atributo calculoVacaiones de la clase empelado
   empleado.setVacaciones(vacaciones);
}
public void calculoTreceavoMes(Empleado empleado){
    //se crea la constante factor
   double factor= 0.083333;
   //se crea la varible local treceavoMes multiplica el salario mensual por el factor
   double treceavoMes = empleado.getSueldoMesual() * factor;
   //se registra el calculo en el atributo TreceavoMes de la clase empelado
   empleado.setTreceavoMes(treceavoMes); 
}
}

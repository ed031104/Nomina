package com.controlador.nomina;

import com.nomina.empleado.Empleado;

public class CalculosNomina {
    //metodo constructor
    public CalculosNomina(){
    }
    
    //metodos 
public void pagoHorasExtras(Empleado empleado){
    double factor= 240;
    empleado.setIngresosHorasExtras((empleado.getSueldoMesual()/factor) *2*empleado.getHorasExtras());
    
}
public void pagoantiguedad(Empleado empleado){
    double pagoantiguedad= 0;
    int añosantiguedad=empleado.getañosAntiguedad();
    double sueldo = empleado.getSueldoMesual(); 
            
    if(añosantiguedad == 1){
            pagoantiguedad = sueldo * 0.03;
        }
            if (añosantiguedad == 2) {
                pagoantiguedad = sueldo * 0.05;
            }   
                if (añosantiguedad == 3) {
                pagoantiguedad = sueldo * 0.07;
                }   
                    if (añosantiguedad == 4) {
                    pagoantiguedad = sueldo * 0.09;
                    }       
                        if(añosantiguedad == 5){
                        pagoantiguedad = sueldo * 0.1;
                        }
                        if (añosantiguedad == 6){
                            pagoantiguedad = sueldo * 0.11;
                        }
                         if(añosantiguedad == 7){
                            pagoantiguedad = sueldo * 0.12;
                         }    
                            if(añosantiguedad == 8){
                            pagoantiguedad = sueldo * 0.13;
                            }      
                                if (añosantiguedad == 9) {
                                    pagoantiguedad = sueldo * 0.14;
                                }       
                                    if(añosantiguedad == 10){
                                        pagoantiguedad = sueldo * 0.15;
                                    }       
                                        if(añosantiguedad == 11){
                                            pagoantiguedad = sueldo * 0.155;
                                        }
                                        
                                        if(añosantiguedad==12){
                                            pagoantiguedad = sueldo * 0.16;
                                            }   
                                                if( añosantiguedad ==13){
                                                pagoantiguedad = sueldo * 0.165;
                                                }   
                                                    if(añosantiguedad == 14){
                                                        pagoantiguedad = sueldo * 0.17;
                                                    }       
                                                        if (añosantiguedad == 15){
                                                            pagoantiguedad = sueldo * 0.175;
                                                        }       
                                                            if(añosantiguedad ==16){
                                                                pagoantiguedad = sueldo * 0.18;
                                                            }       
                                                                if(añosantiguedad==17){
                                                                pagoantiguedad = sueldo * 0.185;
                                                                }   
                                                                    if(añosantiguedad == 18){
                                                                        pagoantiguedad = sueldo * 0.19;
                                                                    }       
                                                                        if(añosantiguedad == 19){
                                                                        pagoantiguedad = sueldo * 0.195;
                                                                        }   
                                                                            if(añosantiguedad >=20){
                                                                                pagoantiguedad = sueldo * 0.20;
     }
       empleado.setPagoAntiguedad(pagoantiguedad);
}
public void calculoSalarioBruto(Empleado empleado){
    
double salarioBruto= empleado.getSueldoMesual() + empleado.getHorasExtras() + empleado.getBono() + empleado.getPagoAntiguedad() ;
empleado.setSalarioBruto(salarioBruto);
}
public void calculoinss(Empleado empleado){
    double calculoinss = empleado.getSalarioBruto() *0.07;
    empleado.setInssLaboral(calculoinss);

}
public void calculoir(Empleado empleado){
    
   double baseImponible = empleado.getSalarioBruto()- empleado.getInssLaboral();
   double sueldoAnual = baseImponible*12;
   empleado.setSueldoAnual(sueldoAnual);
    tarifaProgresivaIr(empleado);
}
public void tarifaProgresivaIr(Empleado empleado){
    
    double sueldoAnual = empleado.getSueldoAnual();
    double deducible = 0;
    double porcentaje = 0;
    double impuestoBase=0;
    double salarioMenosDeducible=0;
    double IrAnual= 0;
    double IrMensual= 0;
    
    if(sueldoAnual >= 1 && sueldoAnual <=100000){
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual = (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >= 100001 && sueldoAnual <=200000){
        deducible = 100000;
        porcentaje= 0.15;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >= 200001 && sueldoAnual <=350000){
        deducible = 200000;
        porcentaje= 0.2;
        impuestoBase = 15000;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >= 350001 && sueldoAnual <=500000){
        deducible = 350000;
        porcentaje= 0.25;
        impuestoBase = 45000;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    if(sueldoAnual >=500001){
        deducible = 500000;
        porcentaje= 0.3;
        impuestoBase = 82500;
        salarioMenosDeducible= sueldoAnual-deducible;
       IrAnual= (salarioMenosDeducible * porcentaje) + impuestoBase;
       IrMensual = IrAnual/12;
    }
    
    empleado.setIr(IrMensual);
}
public void calculoTotalDeducciones(Empleado empleado){
double totaldeducciones= empleado.getInssLaboral()+ empleado.getIr()+ empleado.getPrestamos();
empleado.setTotalDeducciones(totaldeducciones);
}
public void calculoNetoRecibir(Empleado empleado){
double salarioNeto= empleado.getSalarioBruto()-empleado.getTotalDeducciones();
empleado.setNetoRecibir(salarioNeto);
}

    
}

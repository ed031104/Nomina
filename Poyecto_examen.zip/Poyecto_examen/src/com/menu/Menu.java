package com.menu;

import com.login.Controlador_ventana;
import com.login.Login;
import com.menu.views.Nomina;
import com.menu.views.bienvenida;
import com.usuario.Usuario;
import java.awt.Color;
import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {

        Controlador_ventana controlador = new Controlador_ventana();
        bienvenida ventanabienvenida = new bienvenida();
        Nomina ventanaNomina = new Nomina();
        Login ventana; 
        Usuario user;
        
        
        public Menu(Login ventana, Usuario user) {
        initComponents();
        this.ventana = ventana;
        this.user = user;
        TxtUser.setText(user.getNombre_usuario());
        this.setExtendedState(MAXIMIZED_BOTH);
        controlador.hora(TxtHora);
        controlador.cambiarPanel(Panelvista, ventanabienvenida);
    }
        public Menu(){
        }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelMenu = new javax.swing.JPanel();
        separador = new javax.swing.JSeparator();
        Txtmenu = new javax.swing.JLabel();
        TxtSeccionContable = new javax.swing.JLabel();
        BtnNomina = new javax.swing.JPanel();
        TxtNomina = new javax.swing.JLabel();
        BtnSalir = new javax.swing.JPanel();
        txtSalir = new javax.swing.JLabel();
        panelInformacion = new javax.swing.JPanel();
        TxtHora = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Panelvista = new javax.swing.JPanel();
        panelHeader = new javax.swing.JPanel();
        imgUser = new javax.swing.JLabel();
        TxtUser = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(java.awt.Color.white);
        setUndecorated(true);
        setResizable(false);

        PanelMenu.setBackground(new java.awt.Color(255, 153, 153));

        separador.setBackground(new java.awt.Color(255, 255, 255));
        separador.setForeground(new java.awt.Color(255, 255, 255));

        Txtmenu.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        Txtmenu.setForeground(new java.awt.Color(255, 255, 255));
        Txtmenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Txtmenu.setText("MENU");
        Txtmenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TxtmenuMouseClicked(evt);
            }
        });

        TxtSeccionContable.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        TxtSeccionContable.setForeground(new java.awt.Color(255, 255, 255));
        TxtSeccionContable.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TxtSeccionContable.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-calculation-35.png"))); // NOI18N
        TxtSeccionContable.setText("  Contable");

        BtnNomina.setBackground(new java.awt.Color(247, 247, 247));

        TxtNomina.setFont(new java.awt.Font("Roboto Medium", 1, 14)); // NOI18N
        TxtNomina.setForeground(new java.awt.Color(255, 153, 153));
        TxtNomina.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TxtNomina.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-invoice-35 (1).png"))); // NOI18N
        TxtNomina.setText("Nomina");
        TxtNomina.setAutoscrolls(true);
        TxtNomina.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TxtNominaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TxtNominaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TxtNominaMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BtnNominaLayout = new javax.swing.GroupLayout(BtnNomina);
        BtnNomina.setLayout(BtnNominaLayout);
        BtnNominaLayout.setHorizontalGroup(
            BtnNominaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TxtNomina, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        BtnNominaLayout.setVerticalGroup(
            BtnNominaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TxtNomina, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        BtnSalir.setBackground(new java.awt.Color(247, 247, 247));

        txtSalir.setFont(new java.awt.Font("Roboto Medium", 1, 14)); // NOI18N
        txtSalir.setForeground(new java.awt.Color(255, 153, 153));
        txtSalir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-exit-35.png"))); // NOI18N
        txtSalir.setText("cerrar sección");
        txtSalir.setAutoscrolls(true);
        txtSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSalirMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtSalirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtSalirMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BtnSalirLayout = new javax.swing.GroupLayout(BtnSalir);
        BtnSalir.setLayout(BtnSalirLayout);
        BtnSalirLayout.setHorizontalGroup(
            BtnSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtSalir, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
        );
        BtnSalirLayout.setVerticalGroup(
            BtnSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout PanelMenuLayout = new javax.swing.GroupLayout(PanelMenu);
        PanelMenu.setLayout(PanelMenuLayout);
        PanelMenuLayout.setHorizontalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Txtmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(BtnNomina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(BtnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TxtSeccionContable, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(separador, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        PanelMenuLayout.setVerticalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(Txtmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(TxtSeccionContable)
                .addGap(18, 18, 18)
                .addComponent(separador, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(BtnNomina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 216, Short.MAX_VALUE)
                .addComponent(BtnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        panelInformacion.setBackground(new java.awt.Color(255, 204, 204));
        panelInformacion.setForeground(new java.awt.Color(255, 255, 255));

        TxtHora.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        TxtHora.setForeground(new java.awt.Color(255, 255, 255));
        TxtHora.setText("Hoy es {dayname} {day} de {month} de {year}");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-garena-40.png"))); // NOI18N

        javax.swing.GroupLayout panelInformacionLayout = new javax.swing.GroupLayout(panelInformacion);
        panelInformacion.setLayout(panelInformacionLayout);
        panelInformacionLayout.setHorizontalGroup(
            panelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelInformacionLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(TxtHora)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 456, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(32, 32, 32))
        );
        panelInformacionLayout.setVerticalGroup(
            panelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelInformacionLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TxtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(panelInformacionLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        Panelvista.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout PanelvistaLayout = new javax.swing.GroupLayout(Panelvista);
        Panelvista.setLayout(PanelvistaLayout);
        PanelvistaLayout.setHorizontalGroup(
            PanelvistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        PanelvistaLayout.setVerticalGroup(
            PanelvistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        panelHeader.setBackground(new java.awt.Color(255, 255, 255));

        imgUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-usuario-30.png"))); // NOI18N

        TxtUser.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        TxtUser.setForeground(new java.awt.Color(255, 153, 153));
        TxtUser.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        TxtUser.setText("NOMBRE USUARIO");

        jLabel2.setFont(new java.awt.Font("Roboto Medium", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 204, 204));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-macos-cerrar-30.png"))); // NOI18N
        jLabel2.setText("Salir");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelHeaderLayout = new javax.swing.GroupLayout(panelHeader);
        panelHeader.setLayout(panelHeaderLayout);
        panelHeaderLayout.setHorizontalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TxtUser)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(imgUser)
                .addGap(20, 20, 20))
        );
        panelHeaderLayout.setVerticalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelHeaderLayout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(TxtUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(imgUser, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelInformacion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Panelvista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(panelInformacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addComponent(Panelvista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TxtNominaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtNominaMouseEntered
        BtnNomina.setBackground(new Color(240,240,240));
        
    }//GEN-LAST:event_TxtNominaMouseEntered

    private void TxtNominaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtNominaMouseExited
        BtnNomina.setBackground(new Color(247,247,247));
    }//GEN-LAST:event_TxtNominaMouseExited

    private void txtSalirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalirMouseEntered
        BtnSalir.setBackground(new Color(240,240,240));

    }//GEN-LAST:event_txtSalirMouseEntered

    private void txtSalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalirMouseExited
        BtnSalir.setBackground(new Color(247,247,247));

    }//GEN-LAST:event_txtSalirMouseExited

    private void txtSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalirMouseClicked
        Login login=  new Login();
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_txtSalirMouseClicked

    private void TxtNominaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtNominaMouseClicked
        controlador.cambiarPanel(Panelvista, ventanaNomina);



    }//GEN-LAST:event_TxtNominaMouseClicked

    private void TxtmenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtmenuMouseClicked
        controlador.cambiarPanel(Panelvista, ventanabienvenida);

    }//GEN-LAST:event_TxtmenuMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
    Confirmar ventana = new Confirmar();
    ventana.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked


   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BtnNomina;
    private javax.swing.JPanel BtnSalir;
    private javax.swing.JPanel PanelMenu;
    private javax.swing.JPanel Panelvista;
    private javax.swing.JLabel TxtHora;
    private javax.swing.JLabel TxtNomina;
    private javax.swing.JLabel TxtSeccionContable;
    private javax.swing.JLabel TxtUser;
    private javax.swing.JLabel Txtmenu;
    private javax.swing.JLabel imgUser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel panelHeader;
    private javax.swing.JPanel panelInformacion;
    private javax.swing.JSeparator separador;
    private javax.swing.JLabel txtSalir;
    // End of variables declaration//GEN-END:variables
}

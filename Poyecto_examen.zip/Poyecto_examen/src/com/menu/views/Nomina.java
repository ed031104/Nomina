
package com.menu.views;

import com.controlador.fichero.controladorFicheroEmpleado;
import com.controlador.nomina.Controladornomina;
import com.nomina.empleado.ControladorEmpleado;
import com.nomina.empleado.Empleado;
import java.awt.Color;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;


public class Nomina extends javax.swing.JPanel {
        
        controladorFicheroEmpleado empleado = new controladorFicheroEmpleado();
        Controladornomina Controladornomina = new Controladornomina();
        ControladorEmpleado controladorempleado = new ControladorEmpleado();
    
        //metodo constructor
    public Nomina() {
        initComponents();
       nomina.setModel( Controladornomina.MostrarEmpleadosJtable());
       nomina.setBackground(Color.WHITE);
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Backgorund = new javax.swing.JPanel();
        tablaNomina = new javax.swing.JScrollPane();
        nomina = new javax.swing.JTable();
        buscarBtn = new javax.swing.JPanel();
        buscarTxt = new javax.swing.JLabel();
        agregarBtn = new javax.swing.JPanel();
        agregarTxt = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        Cabezera = new javax.swing.JPanel();
        cabezeraTxt = new javax.swing.JLabel();
        EliminatodoBtn = new javax.swing.JPanel();
        eliminarTodoTxt = new javax.swing.JLabel();
        MostrarBtn = new javax.swing.JPanel();
        mostrartodo = new javax.swing.JLabel();

        Backgorund.setBackground(new java.awt.Color(255, 255, 255));

        nomina.setBackground(new java.awt.Color(255, 255, 255));
        nomina.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 204)));
        nomina.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        nomina.setForeground(new java.awt.Color(0, 0, 0));
        nomina.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tablaNomina.setViewportView(nomina);

        buscarBtn.setBackground(new java.awt.Color(255, 153, 153));

        buscarTxt.setBackground(new java.awt.Color(153, 255, 153));
        buscarTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        buscarTxt.setForeground(new java.awt.Color(255, 255, 255));
        buscarTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        buscarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-búsqueda-usuaria-30.png"))); // NOI18N
        buscarTxt.setText("BUSCAR");
        buscarTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buscarTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buscarTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buscarTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout buscarBtnLayout = new javax.swing.GroupLayout(buscarBtn);
        buscarBtn.setLayout(buscarBtnLayout);
        buscarBtnLayout.setHorizontalGroup(
            buscarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(buscarTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        buscarBtnLayout.setVerticalGroup(
            buscarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(buscarTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        agregarBtn.setBackground(new java.awt.Color(255, 153, 153));

        agregarTxt.setBackground(new java.awt.Color(153, 255, 153));
        agregarTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        agregarTxt.setForeground(new java.awt.Color(255, 255, 255));
        agregarTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        agregarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-agregar-usuario-30.png"))); // NOI18N
        agregarTxt.setText("AGREGAR");
        agregarTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                agregarTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                agregarTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout agregarBtnLayout = new javax.swing.GroupLayout(agregarBtn);
        agregarBtn.setLayout(agregarBtnLayout);
        agregarBtnLayout.setHorizontalGroup(
            agregarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, agregarBtnLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(agregarTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        agregarBtnLayout.setVerticalGroup(
            agregarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, agregarBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(agregarTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        nombre.setBackground(new java.awt.Color(255, 255, 255));
        nombre.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        nombre.setForeground(new java.awt.Color(204, 204, 204));
        nombre.setText("  Ingresar nombre o No.INSS");
        nombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 153)));
        nombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombreMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nombreMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                nombreMouseExited(evt);
            }
        });
        nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreActionPerformed(evt);
            }
        });

        Cabezera.setBackground(new java.awt.Color(255, 51, 102));
        Cabezera.setForeground(new java.awt.Color(102, 255, 204));

        cabezeraTxt.setFont(new java.awt.Font("Roboto Medium", 1, 24)); // NOI18N
        cabezeraTxt.setForeground(new java.awt.Color(255, 255, 255));
        cabezeraTxt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        cabezeraTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-registro-45.png"))); // NOI18N
        cabezeraTxt.setText("NOMINA");

        javax.swing.GroupLayout CabezeraLayout = new javax.swing.GroupLayout(Cabezera);
        Cabezera.setLayout(CabezeraLayout);
        CabezeraLayout.setHorizontalGroup(
            CabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cabezeraTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
                .addGap(714, 714, 714))
        );
        CabezeraLayout.setVerticalGroup(
            CabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cabezeraTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        EliminatodoBtn.setBackground(new java.awt.Color(255, 153, 153));

        eliminarTodoTxt.setBackground(new java.awt.Color(153, 255, 153));
        eliminarTodoTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        eliminarTodoTxt.setForeground(new java.awt.Color(255, 255, 255));
        eliminarTodoTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        eliminarTodoTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-eliminar-30.png"))); // NOI18N
        eliminarTodoTxt.setText("ELIMINAR TODO");
        eliminarTodoTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                eliminarTodoTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                eliminarTodoTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                eliminarTodoTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout EliminatodoBtnLayout = new javax.swing.GroupLayout(EliminatodoBtn);
        EliminatodoBtn.setLayout(EliminatodoBtnLayout);
        EliminatodoBtnLayout.setHorizontalGroup(
            EliminatodoBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(eliminarTodoTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
        );
        EliminatodoBtnLayout.setVerticalGroup(
            EliminatodoBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EliminatodoBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(eliminarTodoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        MostrarBtn.setBackground(new java.awt.Color(255, 153, 153));

        mostrartodo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrartodo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-visible-15.png"))); // NOI18N
        mostrartodo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mostrartodoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mostrartodoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                mostrartodoMouseExited(evt);
            }
        });

        javax.swing.GroupLayout MostrarBtnLayout = new javax.swing.GroupLayout(MostrarBtn);
        MostrarBtn.setLayout(MostrarBtnLayout);
        MostrarBtnLayout.setHorizontalGroup(
            MostrarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mostrartodo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
        );
        MostrarBtnLayout.setVerticalGroup(
            MostrarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mostrartodo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout BackgorundLayout = new javax.swing.GroupLayout(Backgorund);
        Backgorund.setLayout(BackgorundLayout);
        BackgorundLayout.setHorizontalGroup(
            BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Cabezera, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BackgorundLayout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(agregarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(buscarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(27, 27, 27)
                .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(MostrarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(EliminatodoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(74, 74, 74))
            .addGroup(BackgorundLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tablaNomina)
                .addGap(9, 9, 9))
        );
        BackgorundLayout.setVerticalGroup(
            BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BackgorundLayout.createSequentialGroup()
                .addComponent(Cabezera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BackgorundLayout.createSequentialGroup()
                        .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(BackgorundLayout.createSequentialGroup()
                                .addGap(179, 179, 179)
                                .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(buscarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(agregarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BackgorundLayout.createSequentialGroup()
                                .addGap(178, 178, 178)
                                .addComponent(EliminatodoBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(63, 63, 63))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BackgorundLayout.createSequentialGroup()
                        .addGap(190, 190, 190)
                        .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MostrarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(74, 74, 74)))
                .addComponent(tablaNomina, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                .addGap(3, 3, 3))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Backgorund, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Backgorund, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreActionPerformed
    }//GEN-LAST:event_nombreActionPerformed

    private void agregarTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarTxtMouseClicked
        controladorempleado.ingresarDatos();
        nomina.setModel(Controladornomina.MostrarEmpleadosJtable());
    }//GEN-LAST:event_agregarTxtMouseClicked

    private void nombreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombreMouseClicked
        nombre.setText("");
        nombre.setForeground(Color.black);
    }//GEN-LAST:event_nombreMouseClicked

    private void eliminarTodoTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarTodoTxtMouseClicked
        Controladornomina nomina = new Controladornomina();
        nomina.borrarTodosEmpleados();
        this.nomina.setModel(Controladornomina.MostrarEmpleadosJtable());
    }//GEN-LAST:event_eliminarTodoTxtMouseClicked

    private void buscarTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buscarTxtMouseClicked
        String nombre = this.nombre.getText();
        Controladornomina.imprimirBusquedaEmpleado(nomina,this.nombre);
                
    }//GEN-LAST:event_buscarTxtMouseClicked

    private void mostrartodoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mostrartodoMouseClicked
    nomina.setModel( Controladornomina.MostrarEmpleadosJtable());

    }//GEN-LAST:event_mostrartodoMouseClicked
    
//colores de los botones
    private void agregarTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarTxtMouseEntered
        agregarBtn.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_agregarTxtMouseEntered

    private void agregarTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarTxtMouseExited
        agregarBtn.setBackground(new Color(255,153,153));
    }//GEN-LAST:event_agregarTxtMouseExited

    private void buscarTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buscarTxtMouseEntered
        buscarBtn.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_buscarTxtMouseEntered

    private void buscarTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buscarTxtMouseExited
        buscarBtn.setBackground(new Color(255,153,153));
    }//GEN-LAST:event_buscarTxtMouseExited

    private void mostrartodoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mostrartodoMouseEntered
        MostrarBtn.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_mostrartodoMouseEntered

    private void mostrartodoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mostrartodoMouseExited
        MostrarBtn.setBackground(new Color(255,153,153));
    }//GEN-LAST:event_mostrartodoMouseExited

    private void eliminarTodoTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarTodoTxtMouseEntered
        EliminatodoBtn.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_eliminarTodoTxtMouseEntered

    private void eliminarTodoTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarTodoTxtMouseExited
        EliminatodoBtn.setBackground(new Color(255,153,153));
    }//GEN-LAST:event_eliminarTodoTxtMouseExited

    private void nombreMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombreMouseEntered
        nombre.setForeground(new Color(180,180,180));
    }//GEN-LAST:event_nombreMouseEntered

    private void nombreMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombreMouseExited
        nombre.setForeground(new Color(204,204,204));
    }//GEN-LAST:event_nombreMouseExited


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Backgorund;
    private javax.swing.JPanel Cabezera;
    private javax.swing.JPanel EliminatodoBtn;
    private javax.swing.JPanel MostrarBtn;
    private javax.swing.JPanel agregarBtn;
    private javax.swing.JLabel agregarTxt;
    private javax.swing.JPanel buscarBtn;
    private javax.swing.JLabel buscarTxt;
    private javax.swing.JLabel cabezeraTxt;
    private javax.swing.JLabel eliminarTodoTxt;
    private javax.swing.JLabel mostrartodo;
    private javax.swing.JTextField nombre;
    private javax.swing.JTable nomina;
    private javax.swing.JScrollPane tablaNomina;
    // End of variables declaration//GEN-END:variables
}

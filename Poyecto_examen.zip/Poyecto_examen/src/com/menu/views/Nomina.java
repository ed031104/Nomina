
package com.menu.views;

import com.controlador.fichero.controladorFicheroEmpleado;
import com.controlador.nomina.Controladornomina;
import com.nomina.empleado.ControladorEmpleado;
import java.awt.Color;


public class Nomina extends javax.swing.JPanel {
        
        controladorFicheroEmpleado empleado = new controladorFicheroEmpleado();
        Controladornomina Controladornomina = new Controladornomina();
        ControladorEmpleado controladorempleado = new ControladorEmpleado();
    
        //metodo constructor
    public Nomina() {
        initComponents();
       nomina.setModel( Controladornomina.MostrarEmpleados());
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Backgorund = new javax.swing.JPanel();
        tablaNomina = new javax.swing.JScrollPane();
        nomina = new javax.swing.JTable();
        eliminarBtn = new javax.swing.JPanel();
        EliminarTxt = new javax.swing.JLabel();
        buscarBtn = new javax.swing.JPanel();
        buscarTxt = new javax.swing.JLabel();
        agregarBtn = new javax.swing.JPanel();
        agregarTxt = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        Cabezera = new javax.swing.JPanel();
        cabezeraTxt = new javax.swing.JLabel();
        bacgroundTabla = new javax.swing.JPanel();
        IrTxt = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        irTabla = new javax.swing.JTable();

        Backgorund.setBackground(new java.awt.Color(255, 255, 255));

        nomina.setBackground(new java.awt.Color(255, 255, 255));
        nomina.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 204)));
        nomina.setFont(new java.awt.Font("Roboto Medium", 0, 14)); // NOI18N
        nomina.setForeground(new java.awt.Color(0, 0, 0));
        nomina.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaNomina.setViewportView(nomina);

        eliminarBtn.setBackground(new java.awt.Color(255, 153, 153));

        EliminarTxt.setBackground(new java.awt.Color(153, 255, 153));
        EliminarTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        EliminarTxt.setForeground(new java.awt.Color(255, 255, 255));
        EliminarTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EliminarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-eliminar-usuaria-30.png"))); // NOI18N
        EliminarTxt.setText(" ELIMINAR");

        javax.swing.GroupLayout eliminarBtnLayout = new javax.swing.GroupLayout(eliminarBtn);
        eliminarBtn.setLayout(eliminarBtnLayout);
        eliminarBtnLayout.setHorizontalGroup(
            eliminarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(EliminarTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
        );
        eliminarBtnLayout.setVerticalGroup(
            eliminarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, eliminarBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(EliminarTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        buscarBtn.setBackground(new java.awt.Color(255, 153, 153));

        buscarTxt.setBackground(new java.awt.Color(153, 255, 153));
        buscarTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        buscarTxt.setForeground(new java.awt.Color(255, 255, 255));
        buscarTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        buscarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-búsqueda-usuaria-30.png"))); // NOI18N
        buscarTxt.setText(" BUSCAR");

        javax.swing.GroupLayout buscarBtnLayout = new javax.swing.GroupLayout(buscarBtn);
        buscarBtn.setLayout(buscarBtnLayout);
        buscarBtnLayout.setHorizontalGroup(
            buscarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(buscarTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        buscarBtnLayout.setVerticalGroup(
            buscarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(buscarTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
        );

        agregarBtn.setBackground(new java.awt.Color(255, 153, 153));

        agregarTxt.setBackground(new java.awt.Color(153, 255, 153));
        agregarTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        agregarTxt.setForeground(new java.awt.Color(255, 255, 255));
        agregarTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        agregarTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-agregar-usuario-30.png"))); // NOI18N
        agregarTxt.setText(" AGREGAR");
        agregarTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarTxtMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout agregarBtnLayout = new javax.swing.GroupLayout(agregarBtn);
        agregarBtn.setLayout(agregarBtnLayout);
        agregarBtnLayout.setHorizontalGroup(
            agregarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(agregarTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
        );
        agregarBtnLayout.setVerticalGroup(
            agregarBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, agregarBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(agregarTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        nombre.setBackground(new java.awt.Color(255, 255, 255));
        nombre.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        nombre.setForeground(new java.awt.Color(204, 204, 204));
        nombre.setText("  Ingresar nombre o No.INSS");
        nombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 153)));
        nombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombreMouseClicked(evt);
            }
        });
        nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreActionPerformed(evt);
            }
        });

        Cabezera.setBackground(new java.awt.Color(255, 51, 102));
        Cabezera.setForeground(new java.awt.Color(102, 255, 204));

        cabezeraTxt.setFont(new java.awt.Font("Roboto Medium", 1, 24)); // NOI18N
        cabezeraTxt.setForeground(new java.awt.Color(255, 255, 255));
        cabezeraTxt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        cabezeraTxt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-registro-45.png"))); // NOI18N
        cabezeraTxt.setText("NOMINA");

        javax.swing.GroupLayout CabezeraLayout = new javax.swing.GroupLayout(Cabezera);
        Cabezera.setLayout(CabezeraLayout);
        CabezeraLayout.setHorizontalGroup(
            CabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cabezeraTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(714, 714, 714))
        );
        CabezeraLayout.setVerticalGroup(
            CabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cabezeraTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        bacgroundTabla.setBackground(new java.awt.Color(255, 204, 204));

        IrTxt.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        IrTxt.setForeground(new java.awt.Color(255, 255, 255));
        IrTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        IrTxt.setText("Calculo IR");

        javax.swing.GroupLayout bacgroundTablaLayout = new javax.swing.GroupLayout(bacgroundTabla);
        bacgroundTabla.setLayout(bacgroundTablaLayout);
        bacgroundTablaLayout.setHorizontalGroup(
            bacgroundTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bacgroundTablaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(IrTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        bacgroundTablaLayout.setVerticalGroup(
            bacgroundTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bacgroundTablaLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(IrTxt)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        irTabla.setBackground(new java.awt.Color(255, 255, 255));
        irTabla.setForeground(new java.awt.Color(0, 0, 0));
        irTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(irTabla);

        javax.swing.GroupLayout BackgorundLayout = new javax.swing.GroupLayout(Backgorund);
        Backgorund.setLayout(BackgorundLayout);
        BackgorundLayout.setHorizontalGroup(
            BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Cabezera, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(BackgorundLayout.createSequentialGroup()
                .addComponent(tablaNomina)
                .addGap(9, 9, 9))
            .addGroup(BackgorundLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BackgorundLayout.createSequentialGroup()
                        .addComponent(agregarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(BackgorundLayout.createSequentialGroup()
                        .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(BackgorundLayout.createSequentialGroup()
                                .addComponent(eliminarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(4, 4, 4))
                            .addComponent(buscarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(16, 16, 16)
                        .addComponent(nombre, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                        .addGap(80, 80, 80)
                        .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bacgroundTabla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE))
                        .addGap(10, 10, 10))))
        );
        BackgorundLayout.setVerticalGroup(
            BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BackgorundLayout.createSequentialGroup()
                .addComponent(Cabezera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(agregarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addGroup(BackgorundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BackgorundLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(eliminarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(buscarBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BackgorundLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(BackgorundLayout.createSequentialGroup()
                        .addComponent(bacgroundTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addComponent(tablaNomina, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                .addGap(3, 3, 3))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Backgorund, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Backgorund, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreActionPerformed
    }//GEN-LAST:event_nombreActionPerformed

    private void agregarTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarTxtMouseClicked
        controladorempleado.ingresarDatos();
        nomina.setModel(Controladornomina.MostrarEmpleados());
    }//GEN-LAST:event_agregarTxtMouseClicked

    private void nombreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombreMouseClicked
        nombre.setText("");
        nombre.setForeground(Color.black);
    }//GEN-LAST:event_nombreMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Backgorund;
    private javax.swing.JPanel Cabezera;
    private javax.swing.JLabel EliminarTxt;
    private javax.swing.JLabel IrTxt;
    private javax.swing.JPanel agregarBtn;
    private javax.swing.JLabel agregarTxt;
    private javax.swing.JPanel bacgroundTabla;
    private javax.swing.JPanel buscarBtn;
    private javax.swing.JLabel buscarTxt;
    private javax.swing.JLabel cabezeraTxt;
    private javax.swing.JPanel eliminarBtn;
    private javax.swing.JTable irTabla;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField nombre;
    private javax.swing.JTable nomina;
    private javax.swing.JScrollPane tablaNomina;
    // End of variables declaration//GEN-END:variables
}

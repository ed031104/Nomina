package com.menu;

import com.login.Controlador_ventana;
import com.login.Login;
import com.menu.views.bienvenida;
import com.usuario.Usuario;
import java.awt.Color;

public class Menu extends javax.swing.JFrame {

        Controlador_ventana controlador = new Controlador_ventana();
        bienvenida ventanabienvenida = new bienvenida();
        Login ventana; 
        Usuario user;
        
        
        public Menu(Login ventana, Usuario user) {
        initComponents();
        this.ventana = ventana;
        this.user = user;
        
        TxtUser.setText(user.getNombre_usuario());
        this.setExtendedState(MAXIMIZED_BOTH);
        controlador.hora(TxtHora);
        controlador.cambiarPanel(Panelvista, ventanabienvenida);
        
        
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelMenu = new javax.swing.JPanel();
        Txtmenu = new javax.swing.JLabel();
        TxtSeccionContable = new javax.swing.JLabel();
        BtnNomina = new javax.swing.JPanel();
        TxtNomina = new javax.swing.JLabel();
        BtnSalir = new javax.swing.JPanel();
        txtSalir = new javax.swing.JLabel();
        separador = new javax.swing.JSeparator();
        panelInformacion = new javax.swing.JPanel();
        TxtHora = new javax.swing.JLabel();
        Panelvista = new javax.swing.JPanel();
        panelHeader = new javax.swing.JPanel();
        imgUser = new javax.swing.JLabel();
        TxtUser = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(java.awt.Color.white);

        PanelMenu.setBackground(new java.awt.Color(255, 153, 153));

        Txtmenu.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        Txtmenu.setForeground(new java.awt.Color(255, 255, 255));
        Txtmenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Txtmenu.setText("MENU");

        TxtSeccionContable.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        TxtSeccionContable.setForeground(new java.awt.Color(255, 255, 255));
        TxtSeccionContable.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TxtSeccionContable.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-calculation-35.png"))); // NOI18N
        TxtSeccionContable.setText("  Contable");

        BtnNomina.setBackground(new java.awt.Color(255, 255, 255));

        TxtNomina.setFont(new java.awt.Font("Roboto Medium", 1, 14)); // NOI18N
        TxtNomina.setForeground(new java.awt.Color(255, 153, 153));
        TxtNomina.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TxtNomina.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-invoice-35 (1).png"))); // NOI18N
        TxtNomina.setText("Nomina");
        TxtNomina.setAutoscrolls(true);
        TxtNomina.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TxtNominaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                TxtNominaMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BtnNominaLayout = new javax.swing.GroupLayout(BtnNomina);
        BtnNomina.setLayout(BtnNominaLayout);
        BtnNominaLayout.setHorizontalGroup(
            BtnNominaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TxtNomina, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BtnNominaLayout.setVerticalGroup(
            BtnNominaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TxtNomina, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        BtnSalir.setBackground(new java.awt.Color(255, 255, 255));

        txtSalir.setFont(new java.awt.Font("Roboto Medium", 1, 14)); // NOI18N
        txtSalir.setForeground(new java.awt.Color(255, 153, 153));
        txtSalir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-exit-35.png"))); // NOI18N
        txtSalir.setText(" Salir");
        txtSalir.setAutoscrolls(true);
        txtSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSalirMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtSalirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtSalirMouseExited(evt);
            }
        });

        javax.swing.GroupLayout BtnSalirLayout = new javax.swing.GroupLayout(BtnSalir);
        BtnSalir.setLayout(BtnSalirLayout);
        BtnSalirLayout.setHorizontalGroup(
            BtnSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtSalir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        BtnSalirLayout.setVerticalGroup(
            BtnSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        separador.setBackground(new java.awt.Color(255, 255, 255));
        separador.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout PanelMenuLayout = new javax.swing.GroupLayout(PanelMenu);
        PanelMenu.setLayout(PanelMenuLayout);
        PanelMenuLayout.setHorizontalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BtnNomina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BtnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(separador)
                    .addComponent(Txtmenu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMenuLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(TxtSeccionContable, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        PanelMenuLayout.setVerticalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(Txtmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(TxtSeccionContable)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(separador, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(BtnNomina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 187, Short.MAX_VALUE)
                .addComponent(BtnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        panelInformacion.setBackground(new java.awt.Color(255, 204, 204));
        panelInformacion.setForeground(new java.awt.Color(255, 255, 255));

        TxtHora.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TxtHora.setForeground(new java.awt.Color(255, 255, 255));
        TxtHora.setText("Hoy es {dayname} {day} de {month} de {year}");

        javax.swing.GroupLayout panelInformacionLayout = new javax.swing.GroupLayout(panelInformacion);
        panelInformacion.setLayout(panelInformacionLayout);
        panelInformacionLayout.setHorizontalGroup(
            panelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelInformacionLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(TxtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(532, Short.MAX_VALUE))
        );
        panelInformacionLayout.setVerticalGroup(
            panelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelInformacionLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(TxtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        Panelvista.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout PanelvistaLayout = new javax.swing.GroupLayout(Panelvista);
        Panelvista.setLayout(PanelvistaLayout);
        PanelvistaLayout.setHorizontalGroup(
            PanelvistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        PanelvistaLayout.setVerticalGroup(
            PanelvistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        panelHeader.setBackground(new java.awt.Color(255, 255, 255));

        imgUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icons8-usuario-30.png"))); // NOI18N

        TxtUser.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        TxtUser.setForeground(new java.awt.Color(255, 153, 153));
        TxtUser.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        TxtUser.setText("NOMBRE USUARIO");

        javax.swing.GroupLayout panelHeaderLayout = new javax.swing.GroupLayout(panelHeader);
        panelHeader.setLayout(panelHeaderLayout);
        panelHeaderLayout.setHorizontalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelHeaderLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TxtUser)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(imgUser)
                .addGap(20, 20, 20))
        );
        panelHeaderLayout.setVerticalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelHeaderLayout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(TxtUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(imgUser, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Panelvista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelInformacion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addComponent(Panelvista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(panelHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(panelInformacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(PanelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TxtNominaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtNominaMouseEntered
        BtnNomina.setBackground(new Color(240,240,240));
        
    }//GEN-LAST:event_TxtNominaMouseEntered

    private void TxtNominaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TxtNominaMouseExited
        BtnNomina.setBackground(new Color(255,255,255));
    }//GEN-LAST:event_TxtNominaMouseExited

    private void txtSalirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalirMouseEntered
        BtnSalir.setBackground(new Color(240,240,240));

    }//GEN-LAST:event_txtSalirMouseEntered

    private void txtSalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalirMouseExited
        BtnSalir.setBackground(new Color(255,255,255));

    }//GEN-LAST:event_txtSalirMouseExited

    private void txtSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSalirMouseClicked
        System.exit(0);
    }//GEN-LAST:event_txtSalirMouseClicked


   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BtnNomina;
    private javax.swing.JPanel BtnSalir;
    private javax.swing.JPanel PanelMenu;
    private javax.swing.JPanel Panelvista;
    private javax.swing.JLabel TxtHora;
    private javax.swing.JLabel TxtNomina;
    private javax.swing.JLabel TxtSeccionContable;
    private javax.swing.JLabel TxtUser;
    private javax.swing.JLabel Txtmenu;
    private javax.swing.JLabel imgUser;
    private javax.swing.JPanel panelHeader;
    private javax.swing.JPanel panelInformacion;
    private javax.swing.JSeparator separador;
    private javax.swing.JLabel txtSalir;
    // End of variables declaration//GEN-END:variables
}

package com.usuario;

import com.controlador.fichero.controladorFichero;
import java.util.ArrayList;

public class ControladorUsuario {

private ArrayList<Usuario> ListaUsuario;
controladorFichero fichero= new controladorFichero();

public ControladorUsuario(){
    ListaUsuario = new ArrayList<>();    
}

//public Usuario BuscarUsuario(String Nombre_usuario){
//    
//    for (int i = 0; i < ListaUsuario.size(); i++) {
//        Usuario usuario = ListaUsuario.get(i);
//        if(usuario != null){
//            if(usuario.getNombre_usuario().equals(Nombre_usuario) ){
//                return usuario;
//            }
//        }
//    }
//    return null;
//}

public boolean AgregarUsuario(Usuario usuario){

    Usuario aux = fichero.leerFicheroUsuario(usuario.getNombre_usuario());
    if(aux == null){
        fichero.ingresarficherousuario(usuario);
        return true;
    }
    return false;
}   
    }




